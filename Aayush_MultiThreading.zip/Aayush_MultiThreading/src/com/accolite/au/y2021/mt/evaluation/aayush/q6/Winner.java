package com.accolite.au.y2021.mt.evaluation.aayush.q6;

public class Winner {
    Horse h;
    int distance;
    int i;
    Speed s;

    public Winner(Horse h, int distance,int i,Speed s) {
        this.h = h;
        this.distance = distance;
        this.i = i;
        this.s=s;
//        s = new Speed();
    }
}